//Base code supplied by Shaun Bangey
//Adapted by Donald Carr
#include <iostream>
#include <sstream>
#include <math.h>
#include <stdlib.h>

#include <qapplication.h>
#include <qgl.h>

#include <Mesh.h>
#include <Curve.h>
#include <BezierSpline.h>

class TextureMap
  {
#define PictureCoords(x,y) (((y) * xsize + (x)) * 3)

    protected:
      int xsize;
      int ysize;
      
      GLubyte * colours;

      GLuint textureid;

    public:
      TextureMap ()
        {
          xsize = 0;
          ysize = 0;
        }
      ~TextureMap ()
        {
          glDeleteTextures (1, &textureid);
          delete [] colours;
        }
      TextureMap (char * filename)
        {
          std::cout << "Loading texture: " << filename << "\n";

          FILE * file;
          if (strstr (filename, "ppm") == NULL)
            {
              char line [MAXSTRING];
              sprintf (line, "pngtopnm %s | pnmflip -tb >tmptexture.pnm", filename);
              system (line);

              file = fopen ("tmptexture.pnm", "r");
            }
          else
            file = fopen (filename, "r");

          if (file == NULL)
            {
              std::cerr << "Could not open pnm file " << filename << "\n";
              exit (1);
            }

          int c;
          if (fscanf (file, "P6\n%d %d\n%d\n", &xsize, &ysize, &c) != 3)
            {
              std::cerr << "Unable to read file header of converted " << filename << "\n";
              exit (1);
            }

          colours = new GLubyte [xsize * ysize * 3];
          fread (colours, xsize * 3, ysize, file);
          fclose (file);

          // set up OpenGL texturing.
          glGenTextures (1, &textureid);

          glBindTexture (GL_TEXTURE_2D, textureid);

          glTexImage2D (GL_TEXTURE_2D, 0, 3, xsize, ysize, 0, GL_RGB,
                        GL_UNSIGNED_BYTE, colours);
          glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
          glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
          glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
          glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
          glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
        }
      // make this texture active.
      void activate ()
        {
          glBindTexture (GL_TEXTURE_2D, textureid);
        }
      int textureID ()
        {
          return textureid;
        }
  };

class Light
  {
    public:
      Point         position;
      GLfloat       colour [4];
      
    Light (Point p, double r, double g, double b)
      {
        position = p;
        colour[0] = r;
        colour[1] = g;
        colour[2] = b;
        colour[3] = 1.0;
      }  
  };

class OpenGLPaintableWidget : public QGLWidget
  {
    Q_OBJECT
      protected:
        Mesh * terrain;
        Mesh * trunk;
	Mesh * bug;

        int mouseox;
        int mouseoy;

        double scale;
        double rotx;
        double roty;
        double offsetx;
        double offsety;
    
        vector <Light *> lights;
    
        TextureMap * terraintexture;
        Curve * camerapath;    
    public:
      /* random number between 0 and 1 */
      double unitrand ()
        {
          return (((double) (random () % 10000)) / 10000.0);
        }
      
      void setTextureCoords (Mesh * m)
        {
          // set the t texture coord based on the height y of the mesh.
          // set the s coord randomly
          double ymin;
          double ymax;
          int started = 0;
          for (int i = 0; i < m->numberVertex (); i++)
            {
              if (!started)
                {
                  ymin = m->getVertex (i)->v.coord[1];
                  ymax = m->getVertex (i)->v.coord[1];
                  started = 1;
                }
              if (m->getVertex (i)->v.coord[1] < ymin)
                ymin = m->getVertex (i)->v.coord[1];
              if (m->getVertex (i)->v.coord[1] > ymax)
                ymax = m->getVertex (i)->v.coord[1];
            }
            
          for (int i = 0; i < m->numberPolygon (); i++)
            {
              for (int j = 0; j < m->getPolygonNumberVertices (i); j++)
                {
                  double h = m->getPolygonVertex (i, j)->v.coord[1];
                  cout << h << " - " << ymin << " .. " << ymax << "\n";
                  Point texc = Point (unitrand (), (h - ymin) / (ymax - ymin), 0.0);
                  m->setPolygonTexCoord (i, j, texc);
                }  
            }
        }
    
      OpenGLPaintableWidget (Mesh * terr, Mesh * tru, Mesh * bu, QWidget *parent, const char *name) : QGLWidget (parent, name)
        {
          terrain = terr;
	  trunk = tru;
	  bug = bu;

          mouseox = -1;
          mouseoy = -1;

          scale = 1.0;
          rotx = 0.0;
          roty = 0.0;
          offsetx = 0.0;
          offsety = 0.0;          
          
          lights.push_back (new Light (Point (5.0, 15.0, -8.0), 0.25, 0.25, 0.65));
          lights.push_back (new Light (Point (0.0, 10.0, 0.0), 0.58, 0.15, 0.15));
          
	  string curvedefn ("10 [ {-2.0,1.8,-2.0} {-2.0,1.8,-1.0} {2.0,1.8,1.0} {2.0,1.8,2.0} {0.0,1.3,3.0} {-2.0,1.8,2.0} {-2.0,1.8,1.0} {2.0,1.8,-1.0} {-2.0,1.8,1.0} {0.0,1.8,-3.0} {-2.0,1.8.-2.0} ]");
          istringstream * str = new istringstream (curvedefn);  
          camerapath = new BezierSpline (*str);
	  
          setMinimumSize (640, 480);
          setMaximumSize (640, 480);
          this->show ();
 
          setTextureCoords (terr);          
        }

      /* random number between -1 and 1 */
      double biunitrand ()
        {
          return (((double) (random () % 10000)) / 5000.0) - 1.0;
        }
	 
      // draw a tree starting at origin in object coordinates,
      // and growing upwards (y axis).	 
      void drawTree (int level)
        {
	  if (level < 0)
	    return;
	  glScalef (0.7, 0.7, 0.7);
	    
	  trunk->render ();
//	  trunk->renderWireframe ();
//          trunk->renderNormals ();
	  glTranslatef (0.0, 1.0, 0.0);
	  
	  int n = 5;
	  double angle = 360.0 / (double) n; // n radial branches
	  for (int i = 0; i < n; i++)
	    {
	      glPushMatrix ();
	      // rotate bent branch around parent.
	      glRotatef (i * angle, 0.0, 1.0, 0.0);
	      // bend branch down.
	      glRotatef (45.0, 1.0, 0.0, 0.0);
	      drawTree (level - 1);
	      glPopMatrix ();
	    }
	}  

      void paintGL ()
        {
	  static double ang = 0.0;
	  static double t = 0.0; // position along the spline.
	  double eyedisp;          
          ang += 4.0;
	  t += 0.001;
          if (t > 1.0)
            t = 0.0;
          
	  glClearColor(0.0, 0.0, 0.0, 0.0);
          glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

          /* sets the x and y coordinates to run from -1 to +1 */
          glColor3f(1.0, 1.0, 1.0);
          glMatrixMode (GL_PROJECTION);
          glLoadIdentity ();
          glTranslatef (eyedisp, 0.0, 0.0);
          glFrustum (-0.1, 0.1, -0.1, 0.1, 0.2, 6.0);
          glTranslatef (-eyedisp, 0.0, 0.0);
          // don't do your transformations in the projection
          // matrix. It may seem to work, but there are nasty
          // side effects.
          glMatrixMode (GL_MODELVIEW);
          glLoadIdentity ();
	  
	  // get the camera to follow a spline.
              
              Point p = camerapath->curveAt (t);
              // to put the camera on the path we would translate from origin to p.
              // in the view transformation, we translate world so that p ends up at
              // the origin.
              Vector tangent = camerapath->derivativeOfCurveAt (t);
              // we currently face [0,0,-1] we want to face in direction t.
              // find a perpendicular vector to rotate around.
              Vector eyedir = Vector (0.0, 0.0, -1.0);
              Vector n = crossProduct (eyedir, tangent);
              double angle = (180.0 / M_PI) * acos (-tangent.coord[2]); // the dot product.
              
              glRotatef (-angle, n.coord[0], n.coord[1], n.coord[2]);
              glTranslatef (-p.coord[0], -p.coord[1], -p.coord[2]);
	  
          int light = GL_LIGHT0;
          for (vector<Light *>::iterator i = lights.begin (); i != lights.end (); i++)
            {
              glLightf (light, GL_SPOT_CUTOFF, 360.0);
              glLightf (light, GL_CONSTANT_ATTENUATION, 1.0);
              glLightf (light, GL_LINEAR_ATTENUATION, 0.2);
              glLightf (light, GL_QUADRATIC_ATTENUATION, 0.0);
          
              GLfloat position [4];
              position[0] = (*i)->position.coord[0];
              position[1] = (*i)->position.coord[1];
              position[2] = (*i)->position.coord[2];
              position[3] = 1.0;
              glLightfv (light, GL_POSITION, position);
              glLightfv (light, GL_AMBIENT, (*i)->colour);
              glLightfv (light, GL_DIFFUSE, (*i)->colour);
              glLightfv (light, GL_SPECULAR, (*i)->colour);
              glEnable (light);

              light++;
            }
	  
          // move the world down slightly so we see the terrain from the top.
          /*
	  glTranslatef (0.0, -8.0, 0.0);
          // fourth, move the whole world back, so that it is
          // suitably positioned for the eye at the origin.
          glTranslatef (0.0, 0.0, -30.0);

          // thirdly offset the center of the object horizontally and vertically.
          glTranslatef (offsetx, offsety, 0.0);
          // then rotate the object about its center.
          
          // use the horizontal movements to rotate about the yaxis.
          glRotatef (roty, 1.0, 0.0, 0.0);
          
          // vertical movements to rotate about the x axis.
          
          glRotatef (rotx, 0.0, 1.0, 0.0);
          // first scale the object about its center.
          glScalef (scale, scale, scale);
		*/
          GLfloat colour [4];
          colour[0] = 0.7;
          colour[1] = 1.0;
          colour[2] = 0.7;
          colour[3] = 1.0;
          glMaterialfv (GL_FRONT_AND_BACK, GL_AMBIENT, colour);            
          glMaterialfv (GL_FRONT_AND_BACK, GL_DIFFUSE, colour);            
          colour[0] = 1.0;
          colour[1] = 0.0;
          colour[2] = 0.;
          colour[3] = 1.0;
          glMaterialfv (GL_FRONT_AND_BACK, GL_SPECULAR, colour);            
	  glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 200.0);
	  glEnable (GL_TEXTURE_2D);
          terraintexture->activate();	  
          terrain->render ();
//	  terrain->renderWireframe ();
//          terrain->renderNormals ();
          glDisable (GL_TEXTURE_2D);
          
          colour[0] = 0.7;
          colour[1] = 0.6;
          colour[2] = 0.4;
          colour[3] = 1.0;
          glMaterialfv (GL_FRONT_AND_BACK, GL_AMBIENT, colour);            
          glMaterialfv (GL_FRONT_AND_BACK, GL_DIFFUSE, colour);            
          glMaterialfv (GL_FRONT_AND_BACK, GL_SPECULAR, colour);            
	  glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 2.0);
          
          // create a forest of trees.
	  glScalef (5.0, 5.0, 5.0);
	  for (int i = 0; i < 1; i++)
	    {
	      glPushMatrix ();
	      srandom (i);
	      glTranslatef (4.0 * biunitrand (), 0.0, 4.0 * biunitrand ());
	      
	      glPushMatrix ();
	      glRotatef (ang, 0.0, 1.0, 0.2);
	      glTranslatef (0.5, 1.2, 0.0);
	      bug->render ();
//	      bug->renderWireframe ();
//	      bug->renderNormals ();
	      glPopMatrix ();
	      
	      drawTree (0);
	      glPopMatrix ();
	    }  
	            
          glFlush();
        }
      void resizeGL (int w, int h)
        {
          glViewport (0, 0, (GLint)w, (GLint)h);
        }

      void mouseMoveEvent (QMouseEvent * ev)
        {
          int x = ev->x ();
          int y = ev->y ();

          if (mouseox < 0)
            {
              mouseox = x;
              mouseoy = y;
              return;
            }

          double diffx = (double) (x - mouseox) / (double) (width ());
          double diffy = (double) (y - mouseoy) / (double) (height ());
          mouseox = x;
          mouseoy = y;

          switch (ev->state ())
            {
              case Qt::LeftButton:
                rotx += (diffx * 360.0);
                roty += (diffy * 360.0);
                break;
              case Qt::MidButton:
                scale *= pow (2.0, diffx * 5.0);
                break;
              case Qt::RightButton:
                offsetx += (10.0 * diffx);
                offsety -= (10.0 * diffy);
                break;
            }
          repaint ();
        }
      
      void mouseReleaseEvent (QMouseEvent * ev)
        {
          mouseox = -1;
          mouseoy = -1;
        }
      void initializeGL ()
        {
          glEnable (GL_DEPTH_TEST);
          
          glShadeModel (GL_SMOOTH);
          glEnable (GL_DEPTH_TEST);

          glEnable (GL_NORMALIZE);          
          glEnable (GL_LIGHTING);
	  glLightModeli (GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);
          GLfloat global_ambient[] = { 0.0, 0.1, 0.0, 1.0 };
          glLightModelfv (GL_LIGHT_MODEL_AMBIENT, global_ambient);
          glLightModeli (GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
          
          terraintexture = new TextureMap ("terrain.png");
	  
        }
  };

int main (int argc, char * argv [])

{
  QApplication a (argc, argv);

  Mesh * m1 = new Mesh ("terrain");  
  Mesh * m2 = new Mesh ("trunk");  
  Mesh * m3 = new Mesh ("bug");  
  OpenGLPaintableWidget w (m1, m2, m3, NULL, "canvas");
  w.show();

  while (1)
    {
      a.processEvents ();
      w.repaint ();
    }
}

#include "ObjectTexture.moc"
